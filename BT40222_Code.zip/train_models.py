import os
import sys
import argparse
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt
import pickle
import json
from datetime import datetime

# Add parent directory to path to import utils.py
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.utils import load_data, split_data, evaluate_model, save_model
from src.models import (
    LinearRegressionModel,
    RidgeRegressionModel,
    RandomForestModel,
    XGBoostModel,
    LightGBMModel,
    SVRModel,
    ARIMAModel, 
    SARIMAXModel,
    LSTMModel,
    GRUModel,
    EnsembleModel
)

def train_models(data_file, models_to_train=None, output_dir='../models', save_results=True):
    """
    Train multiple models and evaluate their performance.
    
    Args:
        data_file (str): Path to the processed data file
        models_to_train (list): List of model names to train
        output_dir (str): Directory to save models and results
        save_results (bool): Whether to save results and models
        
    Returns:
        dict: Dictionary of trained models
    """
    # Create output directories
    os.makedirs(output_dir, exist_ok=True)
    
    # Load data
    print(f"Loading data from {data_file}")
    data = pd.read_csv(data_file)
    
    # Convert date column to datetime if it exists
    if 'datetime' in data.columns:
        data['datetime'] = pd.to_datetime(data['datetime'])
        data.set_index('datetime', inplace=True)
    
    # Prepare data for training
    target_col = 'price'
    X_train, y_train, X_val, y_val, X_test, y_test = split_data(data, target_col)
    
    print(f"Training data shape: {X_train.shape}")
    print(f"Validation data shape: {X_val.shape}")
    print(f"Test data shape: {X_test.shape}")
    
    # Define available models
    available_models = {
        'linear': LinearRegressionModel(),
        'ridge': RidgeRegressionModel(alpha=0.1),
        'random_forest': RandomForestModel(n_estimators=100, max_depth=10),
        'xgboost': XGBoostModel(n_estimators=100, learning_rate=0.05, max_depth=6),
        'lightgbm': LightGBMModel(n_estimators=100, learning_rate=0.05, max_depth=6),
        'svr': SVRModel(kernel='rbf', C=1.0, epsilon=0.1),
        'arima': ARIMAModel(order=(1, 1, 1)),
        'sarimax': SARIMAXModel(order=(1, 1, 1), seasonal_order=(1, 0, 1, 24)),
        'lstm': LSTMModel(seq_length=24, units=50, dropout=0.2, epochs=10, batch_size=32),
        'gru': GRUModel(seq_length=24, units=50, dropout=0.2, epochs=10, batch_size=32)
    }
    
    # Determine which models to train
    if models_to_train is None or len(models_to_train) == 0:
        # Train a simpler subset of models by default
        models_to_train = ['linear', 'ridge', 'random_forest', 'xgboost', 'lightgbm']
    
    # Dictionary to store trained models
    trained_models = {}
    
    # Dictionary to store evaluation metrics
    results = {
        'model_names': [],
        'val_mse': [],
        'val_rmse': [],
        'val_mae': [],
        'val_r2': [],
        'test_mse': [],
        'test_rmse': [],
        'test_mae': [],
        'test_r2': []
    }
    
    # Train and evaluate each model
    for model_name in models_to_train:
        if model_name not in available_models:
            print(f"Model '{model_name}' not found. Available models: {', '.join(available_models.keys())}")
            continue
        
        print(f"\n{'='*50}")
        print(f"Training {model_name} model...")
        
        # Get model
        model = available_models[model_name]
        
        # Train model
        model.fit(X_train, y_train)
        
        # Make predictions on validation set
        val_pred = model.predict(X_val)
        
        # Make predictions on test set
        test_pred = model.predict(X_test)
        
        # Evaluate on validation set
        val_metrics = evaluate_model(y_val, val_pred, model_name)
        print(f"\nValidation metrics for {model_name}:")
        for metric, value in val_metrics.items():
            if metric != 'Model':
                print(f"{metric}: {value:.4f}")
        
        # Evaluate on test set
        test_metrics = evaluate_model(y_test, test_pred, model_name)
        print(f"\nTest metrics for {model_name}:")
        for metric, value in test_metrics.items():
            if metric != 'Model':
                print(f"{metric}: {value:.4f}")
        
        # Store model
        trained_models[model_name] = model
        
        # Store results
        results['model_names'].append(model_name)
        results['val_mse'].append(val_metrics['MSE'])
        results['val_rmse'].append(val_metrics['RMSE'])
        results['val_mae'].append(val_metrics['MAE'])
        results['val_r2'].append(val_metrics['R²'])
        results['test_mse'].append(test_metrics['MSE'])
        results['test_rmse'].append(test_metrics['RMSE'])
        results['test_mae'].append(test_metrics['MAE'])
        results['test_r2'].append(test_metrics['R²'])
        
        # Save model if requested
        if save_results:
            save_model(model, f"{model_name}_model.pkl", output_dir)
            
            # Plot predictions
            plt.figure(figsize=(12, 6))
            plt.plot(y_test.index, y_test.values, label='Actual', linewidth=2)
            plt.plot(y_test.index, test_pred, label='Predicted', linewidth=2, linestyle='--')
            plt.title(f"{model_name.capitalize()} - Test Set Predictions")
            plt.xlabel('Date')
            plt.ylabel('Electricity Price')
            plt.legend()
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(os.path.join(output_dir, f"{model_name}_predictions.png"))
    
    # Create ensemble model using the best models
    if len(trained_models) >= 3 and 'ensemble' in models_to_train:
        print("\nTraining ensemble model...")
        
        # Use validation performance to determine weights
        val_r2_values = results['val_r2']
        
        # Filter out negative R² values and use absolute values
        filtered_models = [trained_models[name] for name, r2 in zip(results['model_names'], val_r2_values) if r2 > 0]
        filtered_weights = [max(0.1, r2) for r2 in val_r2_values if r2 > 0]
        
        if len(filtered_models) >= 2:
            # Create and train ensemble model
            ensemble = EnsembleModel(filtered_models, weights=filtered_weights)
            ensemble.fit(X_train, y_train)
            
            # Make predictions
            val_pred = ensemble.predict(X_val)
            test_pred = ensemble.predict(X_test)
            
            # Evaluate
            val_metrics = evaluate_model(y_val, val_pred, "Ensemble")
            test_metrics = evaluate_model(y_test, test_pred, "Ensemble")
            
            print(f"\nValidation metrics for Ensemble:")
            for metric, value in val_metrics.items():
                if metric != 'Model':
                    print(f"{metric}: {value:.4f}")
            
            print(f"\nTest metrics for Ensemble:")
            for metric, value in test_metrics.items():
                if metric != 'Model':
                    print(f"{metric}: {value:.4f}")
            
            # Store model and results
            trained_models['ensemble'] = ensemble
            results['model_names'].append('ensemble')
            results['val_mse'].append(val_metrics['MSE'])
            results['val_rmse'].append(val_metrics['RMSE'])
            results['val_mae'].append(val_metrics['MAE'])
            results['val_r2'].append(val_metrics['R²'])
            results['test_mse'].append(test_metrics['MSE'])
            results['test_rmse'].append(test_metrics['RMSE'])
            results['test_mae'].append(test_metrics['MAE'])
            results['test_r2'].append(test_metrics['R²'])
            
            # Save model if requested
            if save_results:
                save_model(ensemble, "ensemble_model.pkl", output_dir)
                
                # Plot predictions
                plt.figure(figsize=(12, 6))
                plt.plot(y_test.index, y_test.values, label='Actual', linewidth=2)
                plt.plot(y_test.index, test_pred, label='Predicted', linewidth=2, linestyle='--')
                plt.title("Ensemble Model - Test Set Predictions")
                plt.xlabel('Date')
                plt.ylabel('Electricity Price')
                plt.legend()
                plt.grid(True, alpha=0.3)
                plt.tight_layout()
                plt.savefig(os.path.join(output_dir, "ensemble_predictions.png"))
    
    # Create comparison plot
    plt.figure(figsize=(14, 8))
    plt.plot(y_test.index, y_test.values, label='Actual', linewidth=2)
    
    colors = plt.cm.tab10.colors
    for i, model_name in enumerate(results['model_names']):
        if model_name != 'ensemble':  # Plot ensemble separately
            model = trained_models[model_name]
            test_pred = model.predict(X_test)
            plt.plot(y_test.index, test_pred, label=model_name.capitalize(), 
                    linewidth=1.5, alpha=0.7, color=colors[i % len(colors)])
    
    # Plot ensemble predictions if available
    if 'ensemble' in trained_models:
        test_pred = trained_models['ensemble'].predict(X_test)
        plt.plot(y_test.index, test_pred, label='Ensemble', linewidth=2.5, 
                color='black', linestyle='--')
    
    plt.title("Model Comparison - Test Set Predictions")
    plt.xlabel('Date')
    plt.ylabel('Electricity Price')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    if save_results:
        plt.savefig(os.path.join(output_dir, "model_comparison.png"))
    
    # Create results table
    results_df = pd.DataFrame({
        'Model': results['model_names'],
        'Val MSE': results['val_mse'],
        'Val RMSE': results['val_rmse'],
        'Val MAE': results['val_mae'],
        'Val R²': results['val_r2'],
        'Test MSE': results['test_mse'],
        'Test RMSE': results['test_rmse'],
        'Test MAE': results['test_mae'],
        'Test R²': results['test_r2']
    })
    
    # Sort by test RMSE
    results_df = results_df.sort_values('Test RMSE')
    
    print("\nModel Performance Comparison:")
    print(results_df.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    
    if save_results:
        # Save results to CSV
        results_df.to_csv(os.path.join(output_dir, "model_results.csv"), index=False)
        
        # Save results as JSON for later use
        with open(os.path.join(output_dir, "model_results.json"), 'w') as f:
            json.dump({
                'model_names': results['model_names'],
                'val_mse': [float(x) for x in results['val_mse']],
                'val_rmse': [float(x) for x in results['val_rmse']],
                'val_mae': [float(x) for x in results['val_mae']],
                'val_r2': [float(x) for x in results['val_r2']],
                'test_mse': [float(x) for x in results['test_mse']],
                'test_rmse': [float(x) for x in results['test_rmse']],
                'test_mae': [float(x) for x in results['test_mae']],
                'test_r2': [float(x) for x in results['test_r2']]
            }, f)
    
    return trained_models

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Train electricity price forecasting models.')
    parser.add_argument('--data', type=str, default='data/processed_electricity_prices.csv',
                      help='Path to processed data file')
    parser.add_argument('--models', type=str, nargs='+', 
                      help='Models to train (options: linear, ridge, random_forest, xgboost, lightgbm, svr, arima, sarimax, lstm, gru, ensemble)')
    parser.add_argument('--output', type=str, default='models',
                      help='Directory to save models and results')
    
    args = parser.parse_args()
    
    train_models(args.data, args.models, args.output)