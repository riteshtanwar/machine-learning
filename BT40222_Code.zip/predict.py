import os
import sys
import argparse
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import json

# Add parent directory to path to import utils.py
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.utils import load_data, create_features, load_model, plot_predictions

def load_best_model(models_dir):
    """
    Load the best performing model based on results.
    
    Args:
        models_dir (str): Directory containing models and results
        
    Returns:
        tuple: (model, model_name)
    """
    # Load results
    results_file = os.path.join(models_dir, "model_results.json")
    
    if not os.path.exists(results_file):
        print(f"Results file not found: {results_file}")
        print("Looking for available models...")
        
        # Find available model files
        model_files = [f for f in os.listdir(models_dir) if f.endswith("_model.pkl")]
        
        if not model_files:
            raise FileNotFoundError(f"No model files found in {models_dir}")
        
        # Use the first model file found
        model_file = model_files[0]
        model_name = model_file.replace("_model.pkl", "")
        print(f"Using {model_name} model.")
        
        model = load_model(model_file, models_dir)
        return model, model_name
    
    # Load results from JSON
    with open(results_file, 'r') as f:
        results = json.load(f)
    
    # Find the best model based on test RMSE
    model_names = results['model_names']
    test_rmse = results['test_rmse']
    
    # Create a list of (model_name, rmse) tuples and sort by RMSE
    model_performance = sorted(zip(model_names, test_rmse), key=lambda x: x[1])
    
    best_model_name = model_performance[0][0]
    print(f"Best model based on test RMSE: {best_model_name}")
    
    # Load the best model
    model = load_model(f"{best_model_name}_model.pkl", models_dir)
    
    return model, best_model_name

def make_future_dataset(last_data_point, num_hours=24):
    """
    Create a dataset for future predictions.
    
    Args:
        last_data_point (pd.DataFrame): Last data point from historical data
        num_hours (int): Number of hours to predict into the future
        
    Returns:
        pd.DataFrame: DataFrame with future timestamps
    """
    last_timestamp = last_data_point.index[0]
    
    # Create future timestamps
    future_timestamps = [last_timestamp + timedelta(hours=i+1) for i in range(num_hours)]
    
    # Create empty DataFrame with future timestamps
    future_df = pd.DataFrame(index=future_timestamps)
    future_df.index.name = 'datetime'
    
    # Add price column with NaN values (will be filled with predictions)
    future_df['price'] = np.nan
    
    # Create features for future data
    future_df = create_features(future_df)
    
    # For lag features, use the last known values
    for lag in [1, 24, 48, 168]:
        if f'price_lag_{lag}' in future_df.columns:
            # For the first prediction, use the last known price
            future_df.iloc[0, future_df.columns.get_loc(f'price_lag_{lag}')] = last_data_point['price'].values[0]
    
    return future_df

def predict_future(model, data, num_hours=24, recursive=True):
    """
    Make predictions for future time periods.
    
    Args:
        model: Trained forecasting model
        data (pd.DataFrame): Historical data
        num_hours (int): Number of hours to predict
        recursive (bool): Whether to use recursive forecasting
        
    Returns:
        pd.DataFrame: DataFrame with predictions
    """
    # Get the last data point
    last_data_point = data.iloc[[-1]]
    
    # Create future dataset
    future_df = make_future_dataset(last_data_point, num_hours)
    
    if recursive:
        # Recursive forecasting (use previous predictions as features for next predictions)
        predictions = []
        
        # Make first prediction
        first_pred = model.predict(future_df.iloc[[0]])
        predictions.append(first_pred[0])
        
        # Update future_df with the first prediction
        future_df.iloc[0, future_df.columns.get_loc('price')] = first_pred[0]
        
        # Make remaining predictions
        for i in range(1, num_hours):
            # Update lag features
            for lag in [1, 24, 48, 168]:
                if f'price_lag_{lag}' in future_df.columns:
                    if i >= lag:
                        # Use our own prediction from lag steps ago
                        future_df.iloc[i, future_df.columns.get_loc(f'price_lag_{lag}')] = predictions[i-lag]
                    else:
                        # Use values from historical data
                        if i == 0:
                            future_df.iloc[i, future_df.columns.get_loc(f'price_lag_{lag}')] = last_data_point['price'].values[0]
                        else:
                            # This comes from either historical data or our predictions
                            if lag > i:
                                idx = -lag + i
                                if abs(idx) <= len(data):
                                    future_df.iloc[i, future_df.columns.get_loc(f'price_lag_{lag}')] = data.iloc[idx]['price']
            
            # Make prediction
            pred = model.predict(future_df.iloc[[i]])
            predictions.append(pred[0])
            
            # Update future_df with the prediction
            future_df.iloc[i, future_df.columns.get_loc('price')] = pred[0]
    else:
        # Direct forecasting (make all predictions at once)
        predictions = model.predict(future_df)
        future_df['price'] = predictions
    
    # Create result DataFrame
    result = pd.DataFrame({
        'datetime': future_df.index,
        'predicted_price': future_df['price'].values
    })
    
    return result

def main(data_file, models_dir='../models', hours=24, output_file=None):
    """
    Main function to load data, load model, and make predictions.
    
    Args:
        data_file (str): Path to processed data file
        models_dir (str): Directory containing trained models
        hours (int): Number of hours to predict
        output_file (str): Path to save predictions
        
    Returns:
        pd.DataFrame: DataFrame with predictions
    """
    # Load data
    print(f"Loading data from {data_file}")
    data = pd.read_csv(data_file)
    
    # Convert date column to datetime if necessary
    if 'datetime' in data.columns:
        data['datetime'] = pd.to_datetime(data['datetime'])
        data.set_index('datetime', inplace=True)
    
    # Load best model
    model, model_name = load_best_model(models_dir)
    
    # Make predictions
    print(f"Making predictions for the next {hours} hours using {model_name} model...")
    predictions = predict_future(model, data, hours)
    
    # Print predictions
    print("\nPredictions:")
    print(predictions.to_string(index=False))
    
    # Plot predictions with last 7 days of historical data
    last_week = data.iloc[-24*7:]
    
    plt.figure(figsize=(14, 7))
    plt.plot(last_week.index, last_week['price'], label='Historical', linewidth=2)
    plt.plot(predictions['datetime'], predictions['predicted_price'], label='Predicted', linewidth=2, linestyle='--')
    
    plt.title(f"Electricity Price Forecast - Next {hours} Hours")
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Format x-axis ticks
    plt.gcf().autofmt_xdate()
    
    # Add vertical line at current time
    now = datetime.now()
    plt.axvline(x=now, color='red', linestyle='--', alpha=0.7)
    plt.text(now, plt.ylim()[1]*0.95, 'Now', rotation=90, color='red')
    
    # Save plot if output file is provided
    if output_file:
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        plt.savefig(output_file.replace('.csv', '.png'))
        print(f"Plot saved to {output_file.replace('.csv', '.png')}")
        
        # Save predictions to CSV
        predictions.to_csv(output_file, index=False)
        print(f"Predictions saved to {output_file}")
    
    plt.tight_layout()
    plt.show()
    
    return predictions

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Predict electricity prices using trained models.')
    parser.add_argument('--data', type=str, default='data/processed_electricity_prices.csv',
                      help='Path to processed data file')
    parser.add_argument('--models', type=str, default='models',
                      help='Directory containing trained models')
    parser.add_argument('--hours', type=int, default=24,
                      help='Number of hours to predict')
    parser.add_argument('--output', type=str, default='predictions/forecast.csv',
                      help='Path to save predictions')
    
    args = parser.parse_args()
    
    main(args.data, args.models, args.hours, args.output) 