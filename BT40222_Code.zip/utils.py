import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from datetime import datetime, timedelta

def load_data(file_path):
    """
    Load data from a CSV file.
    
    Args:
        file_path (str): Path to the CSV file
        
    Returns:
        pd.DataFrame: Loaded data
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Data file not found: {file_path}")
    
    data = pd.read_csv(file_path)
    
    # Check if datetime column exists and convert to datetime
    if 'date' in data.columns or 'timestamp' in data.columns or 'datetime' in data.columns:
        datetime_col = next(col for col in ['date', 'timestamp', 'datetime'] if col in data.columns)
        data[datetime_col] = pd.to_datetime(data[datetime_col])
        data.set_index(datetime_col, inplace=True)
    
    return data

def create_features(df):
    """
    Create time-based features from datetime index.
    
    Args:
        df (pd.DataFrame): Input dataframe with datetime index
        
    Returns:
        pd.DataFrame: Dataframe with additional features
    """
    df = df.copy()
    
    # Time-based features
    df['hour'] = df.index.hour
    df['dayofweek'] = df.index.dayofweek
    df['month'] = df.index.month
    df['quarter'] = df.index.quarter
    df['year'] = df.index.year
    df['dayofyear'] = df.index.dayofyear
    df['weekofyear'] = df.index.isocalendar().week
    
    # Cyclical encoding for hour
    df['hour_sin'] = np.sin(2 * np.pi * df['hour']/24)
    df['hour_cos'] = np.cos(2 * np.pi * df['hour']/24)
    
    # Cyclical encoding for day of week
    df['dayofweek_sin'] = np.sin(2 * np.pi * df['dayofweek']/7)
    df['dayofweek_cos'] = np.cos(2 * np.pi * df['dayofweek']/7)
    
    # Cyclical encoding for month
    df['month_sin'] = np.sin(2 * np.pi * df['month']/12)
    df['month_cos'] = np.cos(2 * np.pi * df['month']/12)
    
    # Is weekend or holiday (you may want to expand with actual holiday data)
    df['is_weekend'] = df['dayofweek'].isin([5, 6]).astype(int)
    
    # Add lag features
    for lag in [1, 24, 48, 168]:  # 1 hour, 1 day, 2 days, 1 week
        if 'price' in df.columns:
            df[f'price_lag_{lag}'] = df['price'].shift(lag)
    
    return df

def split_data(df, target_col, train_ratio=0.7, val_ratio=0.15, test_ratio=0.15):
    """
    Split data into train, validation, and test sets.
    
    Args:
        df (pd.DataFrame): Input dataframe
        target_col (str): Target column name
        train_ratio (float): Ratio of training data
        val_ratio (float): Ratio of validation data
        test_ratio (float): Ratio of test data
        
    Returns:
        tuple: X_train, y_train, X_val, y_val, X_test, y_test
    """
    assert train_ratio + val_ratio + test_ratio == 1.0, "Ratios must sum to 1"
    
    n = len(df)
    train_end = int(n * train_ratio)
    val_end = train_end + int(n * val_ratio)
    
    # Get features and target
    X = df.drop(columns=[target_col])
    y = df[target_col]
    
    # Train set
    X_train, y_train = X.iloc[:train_end], y.iloc[:train_end]
    
    # Validation set
    X_val, y_val = X.iloc[train_end:val_end], y.iloc[train_end:val_end]
    
    # Test set
    X_test, y_test = X.iloc[val_end:], y.iloc[val_end:]
    
    return X_train, y_train, X_val, y_val, X_test, y_test

def create_sequences(X, y, seq_length):
    """
    Create sequences for time series forecasting with RNNs/LSTMs.
    
    Args:
        X (np.array): Features array
        y (np.array): Target array
        seq_length (int): Sequence length
        
    Returns:
        tuple: X_seq, y_seq
    """
    X_seq, y_seq = [], []
    
    for i in range(len(X) - seq_length):
        X_seq.append(X[i:i+seq_length])
        y_seq.append(y[i+seq_length])
        
    return np.array(X_seq), np.array(y_seq)

def evaluate_model(y_true, y_pred, model_name="Model"):
    """
    Evaluate model performance with multiple metrics.
    
    Args:
        y_true (np.array): True values
        y_pred (np.array): Predicted values
        model_name (str): Name of the model for printing
        
    Returns:
        dict: Dictionary of metrics
    """
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    
    metrics = {
        "Model": model_name,
        "MSE": mse,
        "RMSE": rmse,
        "MAE": mae,
        "R²": r2,
        "MAPE (%)": mape
    }
    
    return metrics

def plot_predictions(y_true, y_pred, model_name="Model", start_date=None, freq='H'):
    """
    Plot true vs predicted values.
    
    Args:
        y_true (np.array): True values
        y_pred (np.array): Predicted values
        model_name (str): Name of the model
        start_date (datetime): Start date for the plot
        freq (str): Frequency for the date range
        
    Returns:
        matplotlib.figure.Figure: Figure object
    """
    if start_date is None:
        start_date = datetime.now() - timedelta(days=len(y_true)//24)
    
    # Create date range for the x-axis
    if isinstance(y_true, pd.Series) and isinstance(y_true.index, pd.DatetimeIndex):
        dates = y_true.index
    else:
        dates = pd.date_range(start=start_date, periods=len(y_true), freq=freq)
    
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(dates, y_true, label='Actual', linewidth=2)
    ax.plot(dates, y_pred, label='Predicted', linewidth=2, linestyle='--')
    
    # Calculate metrics
    metrics = evaluate_model(y_true, y_pred, model_name)
    metrics_text = f"RMSE: {metrics['RMSE']:.4f}, MAE: {metrics['MAE']:.4f}, R²: {metrics['R²']:.4f}"
    
    ax.set_title(f"{model_name} Predictions vs Actual\n{metrics_text}")
    ax.set_xlabel('Date')
    ax.set_ylabel('Electricity Price')
    ax.grid(True, alpha=0.3)
    ax.legend()
    
    # Format x-axis ticks
    fig.autofmt_xdate()
    
    return fig

def save_model(model, filename, directory='../models'):
    """
    Save a model to disk.
    
    Args:
        model: Model object
        filename (str): Filename
        directory (str): Directory to save the model
    """
    import joblib
    
    if not os.path.exists(directory):
        os.makedirs(directory)
        
    filepath = os.path.join(directory, filename)
    joblib.dump(model, filepath)
    print(f"Model saved to {filepath}")
    
def load_model(filename, directory='../models'):
    """
    Load a model from disk.
    
    Args:
        filename (str): Filename
        directory (str): Directory to load the model from
        
    Returns:
        The loaded model
    """
    import joblib
    
    filepath = os.path.join(directory, filename)
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Model file not found: {filepath}")
    
    model = joblib.load(filepath)
    print(f"Model loaded from {filepath}")
    return model 