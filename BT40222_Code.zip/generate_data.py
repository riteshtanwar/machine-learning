import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import os
import argparse
import matplotlib.pyplot as plt

def generate_synthetic_data(start_date='2023-01-01', days=30, output_file='data/synthetic_electricity_prices.csv'):
    """
    Generate synthetic electricity price data.
    
    Args:
        start_date (str): Start date in YYYY-MM-DD format
        days (int): Number of days to generate
        output_file (str): Output file path
        
    Returns:
        pd.DataFrame: Generated data
    """
    print(f"Generating synthetic electricity price data for {days} days starting from {start_date}")
    
    # Parameters
    hours = 24 * days
    base_price = 50  # Base price in whatever currency
    daily_pattern_amplitude = 10  # Daily price variation
    weekly_pattern_amplitude = 5  # Weekly price variation
    noise_level = 2  # Random noise
    
    # Create date range with hourly frequency
    start = pd.to_datetime(start_date)
    date_range = pd.date_range(start=start, periods=hours, freq='H')
    
    # Create dataframe
    df = pd.DataFrame(index=date_range)
    df.index.name = 'datetime'
    
    # Generate price components
    
    # 1. Base price with slight upward trend
    trend = np.linspace(0, days/30 * 5, hours)  # 5 units increase per month
    
    # 2. Daily pattern (lower at night, higher during the day)
    hour_of_day = np.array([h.hour for h in df.index])
    daily_pattern = np.sin((hour_of_day - 6) * 2 * np.pi / 24) * daily_pattern_amplitude
    
    # 3. Weekly pattern (lower on weekends)
    day_of_week = np.array([d.dayofweek for d in df.index])
    weekend_mask = (day_of_week >= 5).astype(int)  # 1 for weekend, 0 for weekday
    weekly_pattern = -weekend_mask * weekly_pattern_amplitude
    
    # 4. Monthly pattern (higher in winter months in Northern Hemisphere)
    month = np.array([d.month for d in df.index])
    winter_summer = np.sin((month - 1) * 2 * np.pi / 12) * 8  # Higher in January, lower in July
    
    # 5. Random spikes (occasional price surges)
    spikes = np.zeros(hours)
    spike_indices = np.random.choice(hours, size=int(hours*0.01), replace=False)  # 1% of hours have spikes
    spikes[spike_indices] = np.random.uniform(10, 30, size=len(spike_indices))
    
    # 6. Random noise
    noise = np.random.normal(0, noise_level, hours)
    
    # Combine all components
    df['price'] = base_price + trend + daily_pattern + weekly_pattern + winter_summer + spikes + noise
    
    # Ensure no negative prices
    df['price'] = np.maximum(df['price'], 0)
    
    # Round to 2 decimal places
    df['price'] = np.round(df['price'], 2)
    
    # Save to CSV
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    df.to_csv(output_file)
    print(f"Data saved to {output_file}")
    
    return df

def plot_generated_data(df, output_file=None):
    """
    Plot the generated data.
    
    Args:
        df (pd.DataFrame): Generated data
        output_file (str): Output file path for plot
    """
    plt.figure(figsize=(15, 10))
    
    # Plot full time series
    plt.subplot(3, 1, 1)
    plt.plot(df.index, df['price'])
    plt.title('Synthetic Electricity Prices')
    plt.ylabel('Price')
    plt.grid(True, alpha=0.3)
    
    # Plot one week to see daily patterns
    plt.subplot(3, 1, 2)
    one_week = df.iloc[:24*7]
    plt.plot(one_week.index, one_week['price'])
    plt.title('First Week - Daily Patterns')
    plt.ylabel('Price')
    plt.grid(True, alpha=0.3)
    
    # Plot price distribution
    plt.subplot(3, 1, 3)
    plt.hist(df['price'], bins=50)
    plt.title('Price Distribution')
    plt.xlabel('Price')
    plt.ylabel('Frequency')
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file)
        print(f"Plot saved to {output_file}")
    
    plt.show()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Generate synthetic electricity price data.')
    parser.add_argument('--start', type=str, default='2023-01-01',
                      help='Start date in YYYY-MM-DD format')
    parser.add_argument('--days', type=int, default=365,
                      help='Number of days to generate')
    parser.add_argument('--output', type=str, default='data/synthetic_electricity_prices.csv',
                      help='Output file path')
    parser.add_argument('--plot', action='store_true',
                      help='Plot the generated data')
    
    args = parser.parse_args()
    
    df = generate_synthetic_data(args.start, args.days, args.output)
    
    if args.plot:
        plot_output = args.output.replace('.csv', '_plot.png')
        plot_generated_data(df, plot_output)