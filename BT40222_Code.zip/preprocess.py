import os
import sys
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import matplotlib.pyplot as plt
import argparse

# Add parent directory to path to import utils.py
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.utils import load_data, create_features

def download_sample_data():
    """
    Download sample electricity price data if no data is provided.
    Uses Nord Pool electricity market data as an example.
    """
    try:
        import pandas_datareader as pdr
        from datetime import datetime, timedelta
        
        print("No data found. Downloading sample data from Nord Pool electricity market...")
        end_date = datetime.now()
        start_date = end_date - timedelta(days=365)  # 1 year of data
        
        # Using example data - in a real application, you'd use an API for electricity price data
        # This is placeholder using stock data
        data = pdr.data.get_data_yahoo('NEE', start=start_date, end=end_date)  # NextEra Energy as a proxy
        
        # Generate synthetic electricity price data
        data['price'] = data['Close'] * 0.1  # Convert stock price to a reasonable electricity price range
        data = data.rename_axis('datetime')
        data = data[['price']]  # Keep only the price column
        
        # Add random daily and weekly patterns
        hours = np.arange(0, len(data)) % 24
        data['hour_component'] = np.sin(hours * (2 * np.pi / 24)) * 5  # Daily pattern
        days = np.arange(0, len(data)) % 168
        data['weekly_component'] = np.sin(days * (2 * np.pi / 168)) * 10  # Weekly pattern
        
        # Add the patterns and some random noise
        data['price'] = data['price'] + data['hour_component'] + data['weekly_component'] + np.random.normal(0, 2, size=len(data))
        data = data.drop(['hour_component', 'weekly_component'], axis=1)
        
        # Resample to hourly data if not already hourly
        data = data.resample('H').interpolate(method='cubic')
        
        # Ensure the directory exists
        os.makedirs('data', exist_ok=True)
        
        # Save to CSV
        data.to_csv('data/sample_electricity_prices.csv')
        print(f"Sample data saved to 'data/sample_electricity_prices.csv'")
        
        return data
        
    except Exception as e:
        print(f"Error downloading sample data: {e}")
        print("Please provide your own electricity price data in CSV format.")
        sys.exit(1)

def clean_data(df):
    """
    Clean data by handling missing values and outliers.
    
    Args:
        df (pd.DataFrame): Input dataframe
        
    Returns:
        pd.DataFrame: Cleaned dataframe
    """
    print(f"Original data shape: {df.shape}")
    
    # Drop any duplicated timestamps
    df = df[~df.index.duplicated(keep='first')]
    
    # Handle missing values
    if df['price'].isna().sum() > 0:
        print(f"Handling {df['price'].isna().sum()} missing values...")
        # For time series, forward-fill and then backward-fill is often reasonable
        df['price'] = df['price'].interpolate(method='time').ffill().bfill()
    
    # Handle outliers (using IQR method)
    Q1 = df['price'].quantile(0.25)
    Q3 = df['price'].quantile(0.75)
    IQR = Q3 - Q1
    
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    
    outliers = df[(df['price'] < lower_bound) | (df['price'] > upper_bound)]
    
    if len(outliers) > 0:
        print(f"Detected {len(outliers)} outliers ({len(outliers)/len(df)*100:.2f}% of data)")
        
        # Cap outliers instead of removing them (better for time series)
        df.loc[df['price'] < lower_bound, 'price'] = lower_bound
        df.loc[df['price'] > upper_bound, 'price'] = upper_bound
    
    print(f"Cleaned data shape: {df.shape}")
    return df

def visualize_data(df, output_dir='../data'):
    """
    Create exploratory visualizations of the data.
    
    Args:
        df (pd.DataFrame): Input dataframe
        output_dir (str): Directory to save visualizations
    """
    os.makedirs(output_dir, exist_ok=True)
    
    # Price over time
    plt.figure(figsize=(12, 6))
    plt.plot(df.index, df['price'])
    plt.title('Electricity Price over Time')
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'price_over_time.png'))
    
    # Histogram of prices
    plt.figure(figsize=(10, 6))
    plt.hist(df['price'], bins=50, alpha=0.7)
    plt.title('Distribution of Electricity Prices')
    plt.xlabel('Price')
    plt.ylabel('Frequency')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'price_distribution.png'))
    
    # Box plot by hour of day
    hourly_data = df.copy()
    hourly_data['hour'] = hourly_data.index.hour
    
    plt.figure(figsize=(14, 6))
    plt.boxplot([hourly_data[hourly_data['hour'] == h]['price'] for h in range(24)],
               labels=range(24))
    plt.title('Electricity Price by Hour of Day')
    plt.xlabel('Hour')
    plt.ylabel('Price')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'price_by_hour.png'))
    
    # Box plot by day of week
    hourly_data['dayofweek'] = hourly_data.index.dayofweek
    
    plt.figure(figsize=(10, 6))
    plt.boxplot([hourly_data[hourly_data['dayofweek'] == d]['price'] for d in range(7)],
               labels=['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'])
    plt.title('Electricity Price by Day of Week')
    plt.xlabel('Day')
    plt.ylabel('Price')
    plt.xticks(rotation=45)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'price_by_day.png'))
    
    print(f"Visualizations saved to {output_dir}")

def preprocess_data(input_file=None, output_file=None):
    """
    Main function to preprocess electricity price data.
    
    Args:
        input_file (str): Path to input CSV file
        output_file (str): Path to output processed CSV file
    """
    # Load data or download sample data if not provided
    if input_file and os.path.exists(input_file):
        print(f"Loading data from {input_file}")
        df = load_data(input_file)
    else:
        print("No input file provided or file doesn't exist.")
        df = download_sample_data()
    
    # Basic information about the data
    print("\nData Information:")
    print(f"Time range: {df.index.min()} to {df.index.max()}")
    print(f"Total data points: {len(df)}")
    print(f"Price range: {df['price'].min():.2f} to {df['price'].max():.2f}")
    print(f"Average price: {df['price'].mean():.2f}")
    
    # Clean the data
    df = clean_data(df)
    
    # Create features
    df_with_features = create_features(df)
    print(f"\nFeatures created. New shape: {df_with_features.shape}")
    
    # Handle NaN values that might have been introduced by lag features
    df_with_features = df_with_features.dropna()
    
    # Create visualizations
    visualize_data(df)
    
    # Save processed data
    if output_file is None:
        output_file = 'data/processed_electricity_prices.csv'
    
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    df_with_features.to_csv(output_file)
    print(f"\nProcessed data saved to {output_file}")
    
    return df_with_features

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Preprocess electricity price data.')
    parser.add_argument('--input', type=str, help='Path to input CSV file')
    parser.add_argument('--output', type=str, help='Path to output processed CSV file')
    
    args = parser.parse_args()
    
    preprocess_data(args.input, args.output) 